from setuptools import setup

setup(
    name='grapemaster_aiplatform_predictor',
    version='0.1',
    scripts=['predictor.py', 'preprocess.py']
)